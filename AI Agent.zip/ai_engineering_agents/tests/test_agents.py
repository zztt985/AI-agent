from app.main import analyze_task
from app.schemas.models import AnalyzeRequest


def test_analyze_task_returns_plan_and_review():
    result = analyze_task(AnalyzeRequest(task="为订单模块增加异常重试机制"))
    assert len(result.plan) >= 3
    assert len(result.review) >= 1
    assert result.implementation.agent == "ExecutorAgent"
