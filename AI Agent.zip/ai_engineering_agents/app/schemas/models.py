from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any


class AnalyzeRequest(BaseModel):
    task: str = Field(..., description="研发任务或需求描述")
    repo_path: str = Field(default="./examples/sample_repo", description="待分析代码仓库路径")
    context: Optional[str] = Field(default=None, description="补充上下文")


class PlanStep(BaseModel):
    id: int
    title: str
    detail: str
    expected_output: str


class AgentResult(BaseModel):
    agent: str
    summary: str
    data: Dict[str, Any] = Field(default_factory=dict)


class ReviewIssue(BaseModel):
    severity: str
    title: str
    recommendation: str


class AnalyzeResponse(BaseModel):
    task: str
    plan: List[PlanStep]
    implementation: AgentResult
    review: List[ReviewIssue]
    final_recommendation: str
