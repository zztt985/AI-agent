from dataclasses import dataclass
from typing import List
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class MemoryItem:
    title: str
    text: str


class LocalVectorMemory:
    """基于 TF-IDF 的本地轻量记忆检索，便于离线演示。"""

    def __init__(self):
        self.items: List[MemoryItem] = []
        self.vectorizer = TfidfVectorizer()
        self.matrix = None

    def add(self, title: str, text: str) -> None:
        self.items.append(MemoryItem(title=title, text=text))
        self.matrix = self.vectorizer.fit_transform([i.text for i in self.items])

    def search(self, query: str, top_k: int = 3) -> List[MemoryItem]:
        if not self.items or self.matrix is None:
            return []
        query_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(query_vec, self.matrix)[0]
        indices = sims.argsort()[::-1][:top_k]
        return [self.items[i] for i in indices if sims[i] > 0]
