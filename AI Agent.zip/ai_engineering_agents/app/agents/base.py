import os
from typing import Protocol


class LLMClient(Protocol):
    def complete(self, prompt: str) -> str:
        ...


class MockLLMClient:
    """默认 Mock LLM，保证项目无需外部 Key 也能运行。"""

    def complete(self, prompt: str) -> str:
        return "已基于规则引擎完成分析。"


def get_llm_client() -> LLMClient:
    provider = os.getenv("LLM_PROVIDER", "mock").lower()
    if provider != "openai":
        return MockLLMClient()

    try:
        from openai import OpenAI
        model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
        client = OpenAI()

        class OpenAIClient:
            def complete(self, prompt: str) -> str:
                resp = client.responses.create(model=model, input=prompt)
                return resp.output_text

        return OpenAIClient()
    except Exception:
        return MockLLMClient()
