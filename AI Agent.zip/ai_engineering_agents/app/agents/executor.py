from typing import Optional
from app.schemas.models import AgentResult
from app.tools.code_search import CodeSearchTool
from app.memory.vector_store import LocalVectorMemory


class ExecutorAgent:
    """执行 Agent：负责代码分析、方案生成和补丁建议。"""

    def __init__(self, memory: LocalVectorMemory):
        self.memory = memory

    def execute(self, task: str, repo_path: str, context: Optional[str] = None) -> AgentResult:
        keywords = list({w for w in task.replace("，", " ").replace("。", " ").split() if len(w) >= 2})
        tool = CodeSearchTool(repo_path)
        hits = tool.search(keywords or ["service", "api", "test"])

        retrieved = self.memory.search(task)
        memory_context = [{"title": i.title, "text": i.text[:300]} for i in retrieved]

        patch_suggestion = self._build_patch_suggestion(task, hits)

        return AgentResult(
            agent="ExecutorAgent",
            summary="已完成代码上下文检索，并生成实现方案与补丁建议。",
            data={
                "keywords": keywords,
                "code_hits": hits,
                "memory_context": memory_context,
                "extra_context": context,
                "patch_suggestion": patch_suggestion,
            },
        )

    def _build_patch_suggestion(self, task: str, hits):
        target_files = [h["path"] for h in hits[:3]]
        return {
            "design": [
                "采用小步变更，优先修改核心服务层，避免直接侵入控制器和数据库结构。",
                "新增配置开关，支持灰度发布和快速回滚。",
                "对外部依赖增加超时、重试和降级策略。",
                "补充单元测试、异常路径测试和回归测试。"
            ],
            "target_files": target_files,
            "pseudo_code": f