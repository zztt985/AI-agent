from typing import List
from app.schemas.models import PlanStep


class PlannerAgent:
    """规划 Agent：负责需求理解和任务拆解。"""

    def plan(self, task: str) -> List[PlanStep]:
        return [
            PlanStep(
                id=1,
                title="需求澄清与边界识别",
                detail=f"分析需求：{task}；识别涉及模块、输入输出、异常路径与验收标准。",
                expected_output="需求边界、影响范围、验收标准"
            ),
            PlanStep(
                id=2,
                title="代码库检索与上下文补全",
                detail="检索相关模块、历史实现、测试文件和接口定义，构建 RAG 上下文。",
                expected_output="相关文件列表和关键代码片段"
            ),
            PlanStep(
                id=3,
                title="实现方案生成",
                detail="生成最小可行修改方案，优先保证向后兼容、可测试和可灰度。",
                expected_output="实现设计、伪代码、补丁建议"
            ),
            PlanStep(
                id=4,
                title="自动化评审与风险检测",
                detail="检查安全、性能、可维护性、测试覆盖和回滚风险。",
                expected_output="Code Review 结论、风险清单、测试建议"
            ),
        ]
