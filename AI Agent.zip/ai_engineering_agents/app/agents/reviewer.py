from typing import List
from app.schemas.models import AgentResult, ReviewIssue


class ReviewerAgent:
    """评审 Agent：负责质量、安全和风险检测。"""

    def review(self, task: str, implementation: AgentResult) -> List[ReviewIssue]:
        issues: List[ReviewIssue] = []

        code_hits = implementation.data.get("code_hits", [])
        if not code_hits:
            issues.append(ReviewIssue(
                severity="medium",
                title="代码上下文不足",
                recommendation="未检索到足够相关代码，建议补充 repo_path 或接入企业代码检索。"
            ))

        if any(word in task.lower() for word in ["登录", "auth", "token", "权限", "验证码"]):
            issues.append(ReviewIssue(
                severity="high",
                title="安全敏感路径",
                recommendation="涉及认证或权限逻辑，必须增加防绕过测试、频控、防重放和审计日志。"
            ))

        if any(word in task.lower() for word in ["重试", "retry", "消息", "队列", "支付", "订单"]):
            issues.append(ReviewIssue(
                severity="high",
                title="幂等与重复执行风险",
                recommendation="对重试/订单/支付类流程增加幂等键、最大重试次数和死信处理。"
            ))

        issues.append(ReviewIssue(
            severity="low",
            title="测试覆盖建议",
            recommendation="建议覆盖正常路径、异常路径、边界值、并发场景与配置开关关闭场景。"
        ))

        return issues
