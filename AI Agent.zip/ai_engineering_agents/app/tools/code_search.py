from pathlib import Path
from typing import List, Dict


class CodeSearchTool:
    """轻量代码检索工具：扫描常见源码文件并返回关键词命中的片段。"""

    SOURCE_EXTS = {".py", ".js", ".ts", ".tsx", ".java", ".go", ".rs", ".md", ".yaml", ".yml"}

    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)

    def list_files(self) -> List[Path]:
        if not self.repo_path.exists():
            return []
        return [
            p for p in self.repo_path.rglob("*")
            if p.is_file() and p.suffix in self.SOURCE_EXTS and ".venv" not in p.parts
        ]

    def search(self, keywords: List[str], limit: int = 8) -> List[Dict[str, str]]:
        results = []
        for path in self.list_files():
            text = path.read_text(encoding="utf-8", errors="ignore")
            lower = text.lower()
            score = sum(1 for k in keywords if k.lower() in lower)
            if score <= 0:
                continue
            snippet = text[:1200]
            results.append({
                "path": str(path),
                "score": str(score),
                "snippet": snippet
            })
        return sorted(results, key=lambda x: int(x["score"]), reverse=True)[:limit]
