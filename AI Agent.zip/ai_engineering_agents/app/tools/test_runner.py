import subprocess
from pathlib import Path
from typing import Dict


class TestRunnerTool:
    """测试执行工具。生产环境可替换为 CI/CD API。"""

    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)

    def run_pytest(self) -> Dict[str, str]:
        if not self.repo_path.exists():
            return {"status": "skipped", "output": "repo_path does not exist"}
        try:
            completed = subprocess.run(
                ["python", "-m", "pytest", "-q"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=30,
            )
            return {
                "status": "passed" if completed.returncode == 0 else "failed",
                "output": completed.stdout + completed.stderr,
            }
        except Exception as exc:
            return {"status": "error", "output": str(exc)}
