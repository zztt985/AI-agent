import argparse
from dotenv import load_dotenv
from fastapi import FastAPI
from app.schemas.models import AnalyzeRequest, AnalyzeResponse
from app.memory.vector_store import LocalVectorMemory
from app.agents.planner import PlannerAgent
from app.agents.executor import ExecutorAgent
from app.agents.reviewer import ReviewerAgent

load_dotenv()

app = FastAPI(title="AI Engineering Agents", version="1.0.0")


def build_memory() -> LocalVectorMemory:
    memory = LocalVectorMemory()
    memory.add(
        "工程规范",
        "所有核心链路变更必须包含单元测试、异常路径测试、灰度开关、日志和可回滚方案。"
    )
    memory.add(
        "安全规范",
        "认证、授权、验证码、Token、支付相关需求属于高风险变更，需要审计日志和防绕过测试。"
    )
    memory.add(
        "稳定性规范",
        "重试机制必须包含幂等设计、退避策略、最大重试次数、告警和死信处理。"
    )
    return memory


def analyze_task(req: AnalyzeRequest) -> AnalyzeResponse:
    memory = build_memory()
    plan = PlannerAgent().plan(req.task)
    implementation = ExecutorAgent(memory).execute(req.task, req.repo_path, req.context)
    review = ReviewerAgent().review(req.task, implementation)

    high_risk = any(i.severity == "high" for i in review)
    final = "建议进入人工复核后再合并。" if high_risk else "可进入自动化测试和小流量灰度。"

    return AnalyzeResponse(
        task=req.task,
        plan=plan,
        implementation=implementation,
        review=review,
        final_recommendation=final,
    )


@app.post("/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest):
    return analyze_task(req)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", required=True)
    parser.add_argument("--repo-path", default="./examples/sample_repo")
    parser.add_argument("--context", default=None)
    args = parser.parse_args()

    result = analyze_task(AnalyzeRequest(task=args.task, repo_path=args.repo_path, context=args.context))
    print(result.model_dump_json(indent=2, ensure_ascii=False))
