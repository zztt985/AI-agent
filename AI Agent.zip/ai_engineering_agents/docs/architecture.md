# 架构说明

## 核心链路

用户需求 -> PlannerAgent -> CodeSearchTool/RAG Memory -> ExecutorAgent -> ReviewerAgent -> 输出方案

## 推荐生产化增强

1. LLM 网关：统一控制模型、成本、限流和审计。
2. 企业知识库：接入 Confluence/飞书/语雀/Drive 文档作为 RAG。
3. 代码平台：接入 GitHub/GitLab API 自动创建分支和 PR。
4. CI/CD：执行测试、安全扫描、覆盖率分析。
5. 观测体系：记录 Token、耗时、成功率、人工采纳率。
