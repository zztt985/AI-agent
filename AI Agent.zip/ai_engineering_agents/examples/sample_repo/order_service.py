class OrderService:
    def create_order(self, user_id: str, sku_id: str) -> dict:
        if not user_id or not sku_id:
            raise ValueError("user_id and sku_id are required")
        return {"order_id": "demo-order-001", "status": "created"}

    def pay_order(self, order_id: str) -> dict:
        if not order_id:
            raise ValueError("order_id is required")
        return {"order_id": order_id, "status": "paid"}
