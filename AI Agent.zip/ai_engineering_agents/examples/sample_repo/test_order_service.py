import pytest
from order_service import OrderService


def test_create_order_success():
    result = OrderService().create_order("u1", "sku1")
    assert result["status"] == "created"


def test_create_order_invalid():
    with pytest.raises(ValueError):
        OrderService().create_order("", "sku1")
